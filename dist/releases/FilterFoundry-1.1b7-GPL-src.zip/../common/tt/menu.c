#include <dialogs.h>
#include <menus.h>
#include <osutils.h>
#include <textutils.h>
#include <windows.h>

#include "dlg.h"
#include "menu.h"
#include "carbonstuff.h"

void set_item_state(MenuHandle m,short i,Boolean f){
#if TARGET_API_MAC_CARBON
	f ? EnableMenuItem(m,i) : DisableMenuItem(m,i);
#else
	f ? EnableItem(m,i) : DisableItem(m,i);
#endif
}

void draw_popup(DialogPtr d,short i,unsigned char*s){
	static short arrow_data[] = {0xffe0,0x7fc0,0x3f80,0x1f00,0x0e00,0x0400};
	static BitMap arrow = {(void*)arrow_data,2,{0,0,6,11}}; // ppcc wants cast
	Rect r,r2;

	get_item_rect(d,i,&r);
	EraseRect(&r);
	r.right--;
	r.bottom--;
	FrameRect(&r);
	MoveTo(r.left+3,r.bottom);
	LineTo(r.right,r.bottom);
	LineTo(r.right,r.top+3);
	r2 = arrow.bounds;
	OffsetRect(&r2,r.right-17,r.top+6);
	CopyBits(&arrow,GetPortBitMapForCopyBits((CGrafPtr)d),&arrow.bounds,&r2,srcOr,0);
	MoveTo(r.left+15,r.top+13);
	DrawString(s);
}

void adjust_popup(DialogPtr d,short i,MenuHandle m,short mItem,short max,unsigned char *s){
	KIND_ITEM_BOX
	short j;
	unsigned char *t;
	GrafPtr gp;
	Rect r;
	SysEnvRec w;
	
	GetPort(&gp);
	SetPort((GrafPtr)GetWindowPort(GetDialogWindow(d)));
	max -= 12/*info.ascent*/ + 11 + 16;

	GetMenuItemText(m,mItem,s);
	
#if ! TARGET_API_MAC_CARBON
	SysEnvirons(curSysEnvVers,&w);
	if(w.systemVersion < 0x700)
		for(t = s + (j = *s); j && StringWidth(s) > max; *s = j--, t--)
			*t = '�';
	else
#endif
		TruncString(max,s,smTruncEnd);

	GetDialogItem(d,i,&kind,&item,&box);
	InvalWindowRect(GetDialogWindow(d),&box);
	r = box;
	r.left = box.right = box.left + 12 /*info.ascent*/ + StringWidth(s) + 11 + 16;
	EraseRect(&r);
	InvalWindowRect(GetDialogWindow(d),&box);
	SetDialogItem(d,i,kind,item,&box);
	SetPort(gp);
}
