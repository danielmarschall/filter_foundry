/*
	This file is part of "Filter Foundry", a filter plugin for Adobe Photoshop
    Copyright (C) 2002-3 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#define SystemSevenOrLater 1
#include "dialogs.r"
#include "controls.r"
#include "controldefinitions.r"
#include "mactypes.r"

#include "ui.h"
#include "version.h"

include "caution.pict" 'PICT'(16000);
include "zoomin.rsr" 'PICT'(16001);
include "zoomout.rsr" 'PICT'(16002);

/* top,left,bottom,right*/

resource 'ALRT' (ID_ABOUTDLG, purgeable) {
	{0, 0, 216, 360},
	ID_ABOUTDLG,
	silentStages,
	alertPositionMainScreen
};
resource 'DITL' (ID_ABOUTDLG, purgeable) {
	{	/* array DITLarray: 5 elements */
		/* [1] */
		/* [2] */
		{16, 20, 80, 340},
		StaticText {
			disabled,
			"Filter Foundry, version " VERSION_STR
			"\n� 2003-4 Toby Thain <toby@telegraphics.com.au>."
			"\nSee http://www.telegraphics.com.au/sw/ for latest version.\n"
		},
		{88, 20, 200, 340},
		StaticText {
			disabled,
			"If you use this program and like it, please use www.paypal.com to send the author"
			" what you think it is worth (US$5 suggested).\n"
			"Please contact the author with any bug reports, suggestions or comments."
		}
	}
};

resource 'ALRT' (ID_ABOUTSTANDALONEDLG, purgeable) {
	{0, 0, 216, 360},
	ID_ABOUTSTANDALONEDLG,
	silentStages,
	alertPositionMainScreen
};
resource 'DITL' (ID_ABOUTSTANDALONEDLG, purgeable) {
	{	/* array DITLarray: 5 elements */
		/* [1] */
		/* [2] */
		{16, 20, 80, 340},
		StaticText {
			disabled,
			"Filter Foundry, version " VERSION_STR
			"\n� 2003-4 Toby Thain <toby@telegraphics.com.au>."
		},
		{88, 20, 200, 340},
		StaticText {
			disabled,
			"Standalone filter:\n^0 by ^1.\n"
			"^2"
		}
	}
};

resource 'CNTL' (ID_SLIDERCTL){
	{0,0,26,256}, 17/*value:initially, # of ticks*/, visible, /*max*/0xff,/*min*/0,
		kControlSliderProc|kControlSliderLiveFeedback|kControlSliderHasTickMarks, 0, ""
};

resource 'CNTL' (ID_TEXTCTL){
	{0,0,32,459+72}, 0, visible, 0,0, kControlEditTextProc, 0, ""
};

resource 'DLOG' (ID_MAINDLG, purgeable) {
	{0, 0, 461, 554+72},
	kWindowMovableModalDialogProc,
	visible,
	noGoAway,
	0x0,
	ID_MAINDLG,
	"Filter Foundry",
	alertPositionMainScreen
};

resource 'dlgx' (ID_MAINDLG, purgeable){
	versionZero {
		  kDialogFlagsUseThemeBackground
		| kDialogFlagsUseControlHierarchy
		| kDialogFlagsHandleMovableModal
	}
};

resource 'dftb' (ID_MAINDLG, purgeable) {
	versionZero { {
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },

		skipItem { },
		skipItem { },
		skipItem { },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,1/*teJustCenter*/, 0,0,0, -1,-1,-1, "" },

		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },

		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },

		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },

		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },

		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },

		dataItem { kDialogFontUseFontMask|kDialogFontUseFaceMask|kDialogFontUseSizeMask|kDialogFontUseFontNameMask,
			0,14,normal,1/*srcOr*/,0/*teJustLeft*/, 0,0,0, -1,-1,-1, "Courier" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseFaceMask|kDialogFontUseSizeMask|kDialogFontUseFontNameMask,
			0,14,normal,1/*srcOr*/,0/*teJustLeft*/, 0,0,0, -1,-1,-1, "Courier" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseFaceMask|kDialogFontUseSizeMask|kDialogFontUseFontNameMask,
			0,14,normal,1/*srcOr*/,0/*teJustLeft*/, 0,0,0, -1,-1,-1, "Courier" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseFaceMask|kDialogFontUseSizeMask|kDialogFontUseFontNameMask,
			0,14,normal,1/*srcOr*/,0/*teJustLeft*/, 0,0,0, -1,-1,-1, "Courier" },
	} }
};

resource 'DITL' (ID_MAINDLG, purgeable) {
	{
		{426, 536, 446, 606}, Button { enabled, "OK" },
		{426, 451, 446, 521}, Button { enabled, "Cancel" },
		{426, 20, 446, 90}, Button { enabled, "Load�" },
		{426, 105, 446, 175}, Button { enabled, "Save�" },
		{426, 190, 446, 260}, Button { enabled, "Make�" },

		{ 10, 15,210,215}, useritem { disabled }, /* preview area */
		{215, 15,226, 26}, picture { enabled,ID_ZOOMINPICT },
		{215,204,226,215}, picture { enabled,ID_ZOOMOUTPICT },
		{215, 26,231,204}, statictext { enabled,"" },

		{ 10,158+72, 26,228+72}, StaticText { disabled, "ctl(0)" },
		{ 36,158+72, 52,228+72}, StaticText { disabled, "ctl(1)" },
		{ 62,158+72, 78,228+72}, StaticText { disabled, "ctl(2)" },
		{ 88,158+72,104,228+72}, StaticText { disabled, "ctl(3)" },
		{114,158+72,130,228+72}, StaticText { disabled, "ctl(4)" },
		{140,158+72,156,228+72}, StaticText { disabled, "ctl(5)" },
		{166,158+72,182,228+72}, StaticText { disabled, "ctl(6)" },
		{192,158+72,208,228+72}, StaticText { disabled, "ctl(7)" },

		{ 10,238+72, 36,494+72}, control { enabled, ID_SLIDERCTL },
		{ 36,238+72, 62,494+72}, control { enabled, ID_SLIDERCTL },
		{ 62,238+72, 88,494+72}, control { enabled, ID_SLIDERCTL },
		{ 88,238+72,114,494+72}, control { enabled, ID_SLIDERCTL },
		{114,238+72,140,494+72}, control { enabled, ID_SLIDERCTL },
		{140,238+72,166,494+72}, control { enabled, ID_SLIDERCTL },
		{166,238+72,192,494+72}, control { enabled, ID_SLIDERCTL },
		{192,238+72,218,494+72}, control { enabled, ID_SLIDERCTL },

		{ 10,504+72, 26,534+72}, editText { enabled, "" },
		{ 36,504+72, 52,534+72}, editText { enabled, "" },
		{ 62,504+72, 78,534+72}, editText { enabled, "" },
		{ 88,504+72,104,534+72}, editText { enabled, "" },
		{114,504+72,130,534+72}, editText { enabled, "" },
		{140,504+72,156,534+72}, editText { enabled, "" },
		{166,504+72,182,534+72}, editText { enabled, "" },
		{192,504+72,208,534+72}, editText { enabled, "" },

		{158+80, 10,174+80, 40}, StaticText { disabled, "R =" },
		{205+80, 10,221+80, 40}, StaticText { disabled, "G =" },
		{252+80, 10,268+80, 40}, StaticText { disabled, "B =" },
		{299+80, 10,315+80, 40}, StaticText { disabled, "A =" },

		{174+80, 10,190+80, 26}, picture { enabled, ID_CAUTIONPICT },
		{221+80, 10,237+80, 26}, picture { enabled, ID_CAUTIONPICT },
		{268+80, 10,284+80, 26}, picture { enabled, ID_CAUTIONPICT },
		{315+80, 10,331+80, 26}, picture { enabled, ID_CAUTIONPICT },

		{158+80, 45,190+80,534+72}, control { enabled, ID_TEXTCTL },
		{205+80, 45,237+80,534+72}, control { enabled, ID_TEXTCTL },
		{252+80, 45,284+80,534+72}, control { enabled, ID_TEXTCTL },
		{299+80, 45,331+80,534+72}, control { enabled, ID_TEXTCTL },
	}
};

resource 'DLOG' (ID_PARAMDLG, purgeable) {
	{0, 0, 305, 554+72},
	kWindowMovableModalDialogProc,
	visible,
	noGoAway,
	0x0,
	ID_PARAMDLG,
	"",
	alertPositionMainScreen
};

resource 'dlgx' (ID_PARAMDLG, purgeable){
	versionZero {
		  kDialogFlagsUseThemeBackground
		| kDialogFlagsUseControlHierarchy
		| kDialogFlagsHandleMovableModal
	}
};

resource 'dftb' (ID_PARAMDLG, purgeable) {
	versionZero { {
		skipItem { },
		skipItem { },

		skipItem { },
		dataItem { kDialogFontUseFontMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,0, 0,0,0, -1,-1,-1, "" },
		skipItem { },

		skipItem { },
		skipItem { },
		skipItem { },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,1/*teJustCenter*/, 0,0,0, -1,-1,-1, "" },

		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },
		dataItem { kDialogFontUseFontMask|kDialogFontUseJustMask,
			kControlFontSmallSystemFont,0,normal,1/*srcOr*/,-1/*teJustRight*/, 0,0,0, -1,-1,-1, "" },

		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },

		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },
		skipItem { },

	} }
};

resource 'DITL' (ID_PARAMDLG, purgeable) {
	{
		{266, 536, 286, 606}, Button { enabled, "OK" },
		{266, 451, 286, 521}, Button { enabled, "Cancel" },
		{236, 20, 252, 400}, StaticText { disabled,"" },
		{257, 20, 286, 400}, StaticText { disabled,"" },
		{266, 190, 286, 260}, useritem { disabled },

		{ 10, 15,210,215}, useritem { disabled }, /* preview area */
		{215, 15,226, 26}, picture { enabled,ID_ZOOMINPICT },
		{215,204,226,215}, picture { enabled,ID_ZOOMOUTPICT },
		{215, 26,231,204}, statictext { enabled,"" },

		{ 10,158+72, 26,228+72}, StaticText { disabled, "ctl(0)" },
		{ 36,158+72, 52,228+72}, StaticText { disabled, "ctl(1)" },
		{ 62,158+72, 78,228+72}, StaticText { disabled, "ctl(2)" },
		{ 88,158+72,104,228+72}, StaticText { disabled, "ctl(3)" },
		{114,158+72,130,228+72}, StaticText { disabled, "ctl(4)" },
		{140,158+72,156,228+72}, StaticText { disabled, "ctl(5)" },
		{166,158+72,182,228+72}, StaticText { disabled, "ctl(6)" },
		{192,158+72,208,228+72}, StaticText { disabled, "ctl(7)" },

		{ 10,238+72, 36,494+72}, control { enabled, ID_SLIDERCTL },
		{ 36,238+72, 62,494+72}, control { enabled, ID_SLIDERCTL },
		{ 62,238+72, 88,494+72}, control { enabled, ID_SLIDERCTL },
		{ 88,238+72,114,494+72}, control { enabled, ID_SLIDERCTL },
		{114,238+72,140,494+72}, control { enabled, ID_SLIDERCTL },
		{140,238+72,166,494+72}, control { enabled, ID_SLIDERCTL },
		{166,238+72,192,494+72}, control { enabled, ID_SLIDERCTL },
		{192,238+72,218,494+72}, control { enabled, ID_SLIDERCTL },

		{ 10,504+72, 26,534+72}, editText { enabled, "" },
		{ 36,504+72, 52,534+72}, editText { enabled, "" },
		{ 62,504+72, 78,534+72}, editText { enabled, "" },
		{ 88,504+72,104,534+72}, editText { enabled, "" },
		{114,504+72,130,534+72}, editText { enabled, "" },
		{140,504+72,156,534+72}, editText { enabled, "" },
		{166,504+72,182,534+72}, editText { enabled, "" },
		{192,504+72,208,534+72}, editText { enabled, "" },
	}
};

resource 'ALRT' (ID_SYNTAXALERT, purgeable) {
	{0, 0, 148, 320},
	ID_SYNTAXALERT,
	silentStages,
	alertPositionMainScreen
};

resource 'DITL' (ID_SYNTAXALERT, purgeable) {
	{
		{112, 230, 132, 300}, Button { enabled, "OK" },
		{10, 70, 106, 300}, StaticText { disabled, "^0" },
	}
};


data 'CURS' (16000,"hand") {
	$"0180 1A70 2648 264A 124D 1249 6809 9801"            /* .�.p&H&J.M.IhƘ. */
	$"8802 4002 2002 2004 1004 0808 0408 0408"            /* �.@. . ......... */
	$"0180 1BF0 3FF8 3FFA 1FFF 1FFF 6FFF FFFF"            /* .�.�?�?�.�.�o��� */
	$"FFFE 7FFE 3FFE 3FFC 1FFC 0FF8 07F8 07F8"            /* ��.�?�?�.�.�.�.� */
	$"0007 0007"                                          /* .... */
};

resource 'DLOG' (ID_BUILDDLG,purgeable) {
	{0, 0, 403, 408},
	kWindowMovableModalDialogProc,
	visible,
	noGoAway,
	0x0,
	ID_BUILDDLG,
	"Make Standalone Filter",
	alertPositionMainScreen
};

resource 'dlgx' (ID_BUILDDLG, purgeable){
	versionZero {
		  kDialogFlagsUseThemeBackground
//		| kDialogFlagsUseControlHierarchy
		| kDialogFlagsHandleMovableModal
	}
};
resource 'DITL' (ID_BUILDDLG, purgeable) {
	{
		{368, 322, 388, 392},
		Button { enabled,"OK" },
		/* [2] */
		{368, 242, 388, 312},
		Button { enabled,"Cancel" },
		/* [3] */
		{9, 92, 25, 395},
		EditText { enabled,"Filter Foundry" },
		/* [4] */
		{36, 92, 52, 395},
		EditText { enabled,"Untitled" },
		/* [5] */
		{60, 92, 92, 395},
		EditText { enabled,"Filter Foundry Copyright (C) 2003-4 Toby Thain, <toby@telegraphics.com.au>" },
		/* [6] */
		{100, 92, 116, 395},
		EditText { enabled,"Anonymous" },
		/* [7] */
		{152, 89, 168, 174},
		EditText { disabled,"Map 0:" },
		/* [8] */
		{208, 89, 224, 174},
		EditText { disabled,"Map 1:" },
		/* [9] */
		{264, 89, 280, 174},
		EditText { disabled,"Map 2:" },
		/* [10] */
		{320, 89, 336, 174},
		EditText { disabled,"Map 3:" },
		/* [11] */
		{140, 207, 156, 292},
		EditText { disabled,"Control 0:" },
		/* [12] */
		{164, 207, 180, 292},
		EditText { disabled,"Control 1:" },
		/* [13] */
		{196, 207, 212, 292},
		EditText { disabled,"Control 2:" },
		/* [14] */
		{220, 207, 236, 292},
		EditText { disabled,"Control 3:" },
		/* [15] */
		{253, 207, 269, 292},
		EditText { disabled,"Control 4:" },
		/* [16] */
		{277, 207, 293, 292},
		EditText { disabled,"Control 5:" },
		/* [17] */
		{309, 207, 325, 292},
		EditText { disabled,"Control 6:" },
		/* [18] */
		{333, 207, 349, 292},
		EditText { disabled,"Control 7:" },
		/* [19] */
		{151, 20, 169, 83},
		CheckBox { disabled,"Map 0" },
		/* [20] */
		{207, 20, 225, 83},
		CheckBox { disabled,"Map 1" },
		/* [21] */
		{263, 20, 281, 83},
		CheckBox { disabled,"Map 2" },
		/* [22] */
		{319, 21, 337, 84},
		CheckBox { disabled,"Map 3" },
		/* [23] */
		{139, 303, 157, 389},
		CheckBox { disabled,"ctl(0)" },
		/* [24] */
		{163, 303, 181, 389},
		CheckBox { disabled,"ctl(1)" },
		/* [25] */
		{195, 303, 213, 389},
		CheckBox { disabled,"ctl(2)" },
		/* [26] */
		{219, 303, 237, 389},
		CheckBox { disabled,"ctl(3)" },
		/* [27] */
		{252, 303, 270, 389},
		CheckBox { disabled,"ctl(4)" },
		/* [28] */
		{276, 303, 294, 389},
		CheckBox { disabled,"ctl(5)" },
		/* [29] */
		{308, 303, 326, 389},
		CheckBox { disabled,"ctl(6)" },
		/* [30] */
		{332, 303, 350, 389},
		CheckBox { disabled,"ctl(7)" },

		{372, 21, 388, 150},
		CheckBox { enabled,"Protect" },

		{9, 7, 25, 83},
		StaticText { disabled,"Category:" },
		/* [44] */
		{36, 7, 52, 83},
		StaticText { disabled,"Title:" },
		/* [45] */
		{60, 7, 76, 83},
		StaticText { disabled,"Copyright:" },
		/* [46] */
		{100, 7, 116, 83},
		StaticText { disabled,"Author:" },
	}
};
