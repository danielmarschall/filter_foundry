/*
	This file is part of "Filter Foundry", a filter plugin for Adobe Photoshop
    Copyright (C) 2002-3 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "ff.h"
#include "symtab.h"

#include "PIActions.h"

#include "compat_string.h"

long event_id;

unsigned long printablehash(unsigned long hash){
	unsigned long key;
	int i;
	
	for(key=0,i=4;i--;){
		key <<= 8;
		key |= ' ' + (hash % 95); /* get a printable character from hash */
		hash /= 95;
	}
	return key;
}

long fixpipl(PIPropertyList *pipl,long origsize,StringPtr title){
	PIProperty *prop;
	struct hstm_data{
		long version; /* = 0 */
		long class_id;
		long event_id;
		short aete_resid;
		char scope[1];
	};
	struct hstm_data *hstm;
	char str[0x100],*p;
	unsigned long hash;

	pipl->count += 3; // more keys in PiPL

	prop = (PIProperty*)((char*)pipl + origsize);

	/* add Title/Name property key */
	
	prop->vendorID = kPhotoshopSignature;
	prop->propertyKey = PINameProperty;
	prop->propertyID = 0;
	prop->propertyLength = title[0]+1;
	PLstrcpy((StringPtr)prop->propertyData,title);
	(char*)prop += (16+prop->propertyLength+3) & -4;
	
	/* add Category property key */
	
	prop->vendorID = kPhotoshopSignature;
	prop->propertyKey = PICategoryProperty;
	prop->propertyID = 0;
	prop->propertyLength = gdata->parm.category[0]+1;
	PLstrcpy((StringPtr)prop->propertyData,gdata->parm.category);
	(char*)prop += (16+prop->propertyLength+3) & -4;

	/* add HasTerminology property key */	

	/* construct scope string by concatenating Category and Title - hopefully unique! */
	hstm = (struct hstm_data*)prop->propertyData;
	p = hstm->scope;
	memcpy(p,gdata->parm.category+1,gdata->parm.category[0]);
	p += gdata->parm.category[0];
	*p++ = ' ';
	memcpy(p,title+1,title[0]);
	p += title[0];
	*p++ = 0;

	/* make up a new event ID for this aete, based on printable base-95 hash of scope */
	hash = djb2(hstm->scope);
	event_id = printablehash(hash);

	prop->vendorID = kPhotoshopSignature;
	prop->propertyKey = PIHasTerminologyProperty;
	prop->propertyID = 0;
	prop->propertyLength = 14 + (p - hstm->scope);
	hstm->version = 0;
	hstm->class_id = plugInClassID;
	hstm->event_id = event_id;
	hstm->aete_resid = AETE_ID;
	
	(char*)prop += (16+prop->propertyLength+3) & -4;

	return (char*)prop - (char*)pipl;
}

/* Mac aete resources include word alignments after string pairs; Windows ones apparently don't */
#ifdef MAC_ENV
	#define ALIGNWORD(j) (j += j & 1)
#else
	#define ALIGNWORD(j)
#endif
#define SKIP_PSTR(j) (j += 1+aete[j])

long fixaete(unsigned char *aete,long origsize,StringPtr title){
	int offset,oldlen,newlen,desclen,oldpad,newpad;
	char s[0x100];
	Str255 desc;
	
	offset = 8; /* point at suite name */

	SKIP_PSTR(offset); /* skip suite name (vendor) [maybe this should become author??] */
	SKIP_PSTR(offset); /* skip suite description [set this from dialog field??] */
	ALIGNWORD(offset);
	offset += 4+2+2+2;
	
	/* now p points to filter name. */
	oldlen = aete[offset];
	newlen = title[0];

	/* shift aete data taking into account new title string */
	desclen = aete[offset+1+oldlen];
	PLstrcpy(desc,(StringPtr)(aete+offset+1+oldlen));  /* save description string... */
#ifdef MAC_ENV
	/* see if alignment padding is necessary */
	oldpad = (oldlen + desclen) & 1;
	newpad = (newlen + desclen) & 1;
#else
	oldpad = newpad = 0;
#endif
	/* shift latter part of aete data, taking into account new string lengths */
	memcpy(aete+offset+1+newlen+newpad, 
			 aete+offset+1+oldlen+oldpad, 
			 origsize-offset-1-oldlen-oldpad); /* phew! */
	/* copy in new title string */
	PLstrcpy((StringPtr)(aete+offset),title);
	/* copy description string into right place... [this could be new description from dialog field??] */
	PLstrcpy((StringPtr)(aete+offset+1+newlen),desc); 
	
	SKIP_PSTR(offset); /* skip (new) event name */
	SKIP_PSTR(offset); /* skip event description */
	ALIGNWORD(offset);
	
	/* set event ID */
	*(unsigned long*)(aete+offset+4) = event_id; /* FIXME: this might be unaligned access on some platforms?? */

	return origsize-oldlen-oldpad+newlen+newpad;
}
