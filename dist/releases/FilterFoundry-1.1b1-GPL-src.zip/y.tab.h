#ifndef YYSTYPE
#define YYSTYPE int
#endif
#define	TOK_NUM	257
#define	TOK_EOF	258
#define	TOK_ARGSEP	259
#define	TOK_FN1	260
#define	TOK_FN2	261
#define	TOK_FN3	262
#define	TOK_FN4	263
#define	TOK_FN5	264
#define	TOK_FN10	265
#define	TOK_SPECIALVAR	266
#define	TOK_VAR	267
#define	TOK_UNKNOWN	268
#define	TOK_BADCHAR	269
#define	LOGAND	270
#define	LOGOR	271
#define	EQ	272
#define	NE	273
#define	LE	274
#define	GE	275
#define	SHLEFT	276
#define	SHRIGHT	277
#define	EXP	278
#define	NEG	279


extern YYSTYPE yylval;
