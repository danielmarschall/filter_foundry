/*
	This file is part of "Filter Foundry", a filter plugin for Adobe Photoshop
    Copyright (C) 2002-3 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "ff.h"

#include "file_compat.h"
#include "sprintf_tiny.h"

enum{ CHOPLINES = 63 };

OSErr putstr(Handle h,char *s);

OSErr putstr(Handle h,char *s){
	Ptr p;
	OSErr e;
	long size = PIGETHANDLESIZE(h),n = strlen(s);
	
	if(!(e = PISETHANDLESIZE(h,size+n))){
		p = PILOCKHANDLE(h,false);
		memcpy(p+size,s,n);
		PIUNLOCKHANDLE(h);
	}
	return e;
}

OSErr saveparams(Handle h){
	char outbuf[CHOPLINES*2+2],*q,*p;
	int i,j,chunk,n;
	OSErr e;
	
	if( !(e = PISETHANDLESIZE(h,0)) && !(e = putstr(h,"%RGB-1.0\n")) ){
		
		/* slider values */
		for( i=0 ; i<8 ; ++i ){
			q = int_str(outbuf,slider[i],10);
			*q++ = '\n';
			*q = 0;
			if(e = putstr(h,outbuf))
				break;
		}
		
		/* expressions */
		if(!e)
			for( i=0 ; i<4 ; ++i ){
				if(p = expr[i])
					for( n = strlen(p) ; n ; n -= chunk ){
						chunk = n>CHOPLINES ? CHOPLINES : n;
						for( j = chunk,q = outbuf ; j-- ; )
							if(*p == CR){
								*q++ = '\\';
								*q++ = 'r';
								++p;
							}else 
								*q++ = *p++;
						*q++ = '\n';
						*q = 0;
						if(e = putstr(h,outbuf))
							goto err;
					}
				else
					if(e = putstr(h,"(null expr)\n")) // this shouldn't happen
						goto err;
				if(e = putstr(h,"\n"))
					break;
			}
	}
err:
	return e;
}

OSErr savehandleintofile(Handle h,FILEREF r){
	Ptr p = PILOCKHANDLE(h,false);
	long n = PIGETHANDLESIZE(h);
	OSErr e = FSWrite(r,&n,p);
	PIUNLOCKHANDLE(h);
	return e;
}

Boolean savefile(StandardFileReply *sfr){
	FILEREF r;
	Handle h;
	Boolean res = false;
	char *reasonstr = "";

	FSpDelete(&sfr->sfFile);
	if(!FSpCreate(&sfr->sfFile,kPhotoshopSignature,'TEXT',sfr->sfScript))
		if(!FSpOpenDF(&sfr->sfFile,fsWrPerm,&r)){

			if(h = PINEWHANDLE(0)){
				res = !(saveparams(h) || savehandleintofile(h,r)) ;
				PIDISPOSEHANDLE(h);
			}

			FSClose(r);
		}else reasonstr = ("Could not open the file.");
	else reasonstr = ("Could not create the file.");

	if(!res)
		alertuser("Could not save settings.",reasonstr);

	return res;
}
