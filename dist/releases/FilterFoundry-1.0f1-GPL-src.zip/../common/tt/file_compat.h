/*
	This file is part of icoformat, a Windows Icon (ICO) File Format
	plugin for Adobe Photoshop
    Copyright (C) 2002-3 Toby Thain, toby@telegraphics.com.au

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by  
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License  
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef COMPAT_FILE_H
#define COMPAT_FILE_H

#ifdef macintosh

	#include <files.h>
	
	#if defined(WANT_LARGE_FILES) && ! TARGET_CPU_68K
		// large file support (HFS+)
		typedef SInt16 FILEREF;
		typedef SInt64 FILEPOS;
		typedef ByteCount FILECOUNT;
		
		#define FSPOPENDF fspopendf_large
		#define FSCLOSE FSCloseFork
		#define FSREAD fsread_large
		#define FSWRITE fswrite_large
		#define GETFPOS getfpos_large
		#define SETFPOS setfpos_large
		#define GETEOF geteof_large
	#else
		// old-style HFS
		typedef short FILEREF;
		typedef long FILEPOS,FILECOUNT;

		#define FSPOPENDF FSpOpenDF
		#define FSREAD FSRead
		#define FSWRITE FSWrite
		#define GETFPOS GetFPos
		#define SETFPOS SetFPos
		#define GETEOF GetEOF
	#endif

	Boolean host_has_forks(void);
	extern Boolean has_forks;

#else // not macintosh

	#ifdef WIN32

		#include "compat_win.h"
		
		#ifndef INVALID_SET_FILE_POINTER
			#define INVALID_SET_FILE_POINTER 0xffffffff
		#endif

		typedef HANDLE FILEREF;
		typedef LONG FILECOUNT;

		#define FSPOPENDF FSpOpenDF
		#define FSREAD FSRead
		#define FSWRITE FSWrite
		#ifdef WANT_LARGE_FILES
			typedef UINT64 FILEPOS;
			#define GETFPOS getfpos_large
			#define SETFPOS setfpos_large
			#define GETEOF geteof_large
		#else
			typedef DWORD FILEPOS;
			#define GETFPOS GetFPos
			#define SETFPOS SetFPos
			#define GETEOF GetEOF
		#endif

		OSErr FSpOpenDF(const FSSpec *spec, int permission, FILEREF *refNum);
		OSErr FSpCreate(const FSSpec *spec, OSType creator, OSType fileType, ScriptCode scriptTag);
		OSErr FSpDelete(const FSSpec *spec);
	#else
		// UNIX
		#include <stdio.h>
		
		typedef FILE *FILEREF;
		typedef int OSErr;
		
		#define noErr 0
		#define ioErr				(-36)
		
	#endif

		enum {
			fsCurPerm					= 0,
			fsRdPerm					= 1,
			fsWrPerm					= 2,
			fsRdWrPerm					= 3,
		};
		enum {
		  fsAtMark                      = 0,    /* positioning modes in ioPosMode */
		  fsFromStart                   = 1,
		  fsFromLEOF                    = 2,
		  fsFromMark                    = 3
		};
	
		OSErr FSClose(FILEREF f);
		OSErr FSRead(FILEREF f, long *count, void *buffPtr);
		OSErr FSWrite(FILEREF f, long *count, const void *buffPtr);
		OSErr GetFPos(FILEREF   refNum,long *  filePos);
		OSErr SetFPos(FILEREF   refNum,short   posMode,long    posOff);
		OSErr GetEOF(FILEREF   refNum,long *  logEOF);
		OSErr SetEOF(FILEREF   refNum,long logEOF);
		/*
		HMODULE FSpOpenResFile(const FSSpec *  spec,SignedByte      permission);
		void CloseResFile(HMODULE hmodule);
		HGLOBAL GetResource(ResType   theType,short     theID);
		*/

#endif

OSErr fspopendf_large(const FSSpec *spec, int perm, FILEREF *refNum);
OSErr fsread_large(FILEREF refNum,FILECOUNT *count,void *buffPtr);
OSErr fswrite_large(FILEREF refNum,FILECOUNT *count,const void *buffPtr);
OSErr getfpos_large(FILEREF refNum,FILEPOS *filePos);
OSErr setfpos_large(FILEREF refNum,short posMode,FILEPOS posOff);
OSErr geteof_large(FILEREF refNum,FILEPOS *logEOF);

#endif
