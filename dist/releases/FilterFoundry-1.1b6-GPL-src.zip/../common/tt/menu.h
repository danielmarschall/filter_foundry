#include <dialogs.h>
#include <menus.h>
#include <controldefinitions.h>

#define POPUP_MENUHANDLE(ch) ( (PopupPrivateData*) *((*ch)->contrlData) )->mHandle

// this has disappeared from header files... still needed
// as there's no GetControlPopupMenuHandle in the API on 68K
/* it's now in controldefinitions.h!
typedef struct PopupPrivateData {
	MenuHandle						mHandle;
	SInt16							mID;
} PopupPrivateData;
*/

void set_item_state(MenuHandle m,short i,Boolean f);
void draw_popup(DialogPtr d,short i,unsigned char*s);
void adjust_popup(DialogPtr d,short i,MenuHandle m,short mItem,short max,unsigned char*s);
